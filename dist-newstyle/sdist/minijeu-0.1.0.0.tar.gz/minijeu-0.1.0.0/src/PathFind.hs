module PathFind where

import qualified Data.Map as Map
import Data.List (minimumBy, find)
import Data.Ord (comparing)
import qualified Data.PQueue.Min as PQ
import qualified Data.Map.Strict as Map
import Data.Maybe (fromMaybe, listToMaybe)
import SimCity




-- Définition de la fonction heuristique pour A*
heuristic :: Coord -> Coord -> Int
heuristic (C x1 y1) (C x2 y2) = abs (x2 - x1) + abs (y2 - y1)



-- Définition d'un type pour les nœuds utilisés dans A*
data Node = Node {
    coord :: Coord,
    parent :: Maybe Node,
    g :: Int,
    h :: Int
} deriving (Eq, Show)

aStar :: Coord -> Coord -> Ville -> Maybe [Coord]
aStar start goal ville
    | start == goal = Just [start]
    | otherwise = let
        openSet = PQ.singleton (manhattanDistance start goal, start)
        cameFrom = Map.empty :: Map.Map Coord Coord
        gScore = Map.singleton start 0
        fScore = Map.singleton start (manhattanDistance start goal)
      in aStarHelper openSet cameFrom gScore fScore
  where
    aStarHelper openSet cameFrom gScore fScore
        | PQ.null openSet = Nothing
        | otherwise = 
            let ((_, current), openRest) = PQ.deleteFindMin openSet
            in if current == goal
               then Just (reconstructPath cameFrom current [])
               else let
                    neighbors = getNeighbors current ville
                    newOpenSet = foldr (processNeighbor current) openRest neighbors
                in aStarHelper newOpenSet (Map.insert current current cameFrom) gScore fScore

    processNeighbor current neighbor openSet =
        let tentativeGScore = (fromMaybe maxBound (Map.lookup current gScore)) + 1
            gScoreNeighbor = fromMaybe maxBound (Map.lookup neighbor gScore)
        in if tentativeGScore < gScoreNeighbor
           then let
                    neighborGScore = Map.insert neighbor tentativeGScore gScore
                    neighborFScore = Map.insert neighbor (tentativeGScore + manhattanDistance neighbor goal) fScore
                    newOpenSet = PQ.insert (neighborFScore Map.! neighbor, neighbor) openSet
                in newOpenSet
           else openSet

    reconstructPath cameFrom current path
        | Map.member current cameFrom = reconstructPath cameFrom (cameFrom Map.! current) (current : path)
        | otherwise = current : path




