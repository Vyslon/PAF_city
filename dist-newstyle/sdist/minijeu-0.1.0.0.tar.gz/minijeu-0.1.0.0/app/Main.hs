import Control.Monad (unless, when)
import Control.Concurrent (threadDelay)
import Data.Set (Set)
import qualified Data.Set as Set
import Data.List (foldl')
import Foreign.C.Types (CInt(..))
import SDL 
import SDL.Time (time, delay)
import Linear (V4(..))
import TextureMap (TextureMap, TextureId(..))
import qualified TextureMap as TM
import Sprite (Sprite)
import qualified Sprite as S
import SpriteMap (SpriteMap, SpriteId(..))
import qualified SpriteMap as SM
import Keyboard (Keyboard)
import qualified Keyboard as K
import Mouse (MyMouse)
import qualified Mouse as MS
import Model (GameState)
import qualified Model as M
import qualified Data.Map as Map
import qualified SimCity as Sim
import Data.Text (pack)
import qualified SDL.Font as TTF 
import SDL (initialize, InitFlag(InitVideo, InitAudio))

-- Custom initialization function
customInitialize :: IO ()
customInitialize = do
    initialize [InitVideo, InitAudio]  -- Initialize necessary SDL subsystems
    TTF.initialize  -- Initialize the SDL.Font subsystem

cleanup :: IO ()
cleanup = do
    TTF.quit  -- Quit the SDL.Font subsystem
    SDL.quit  -- Quit SDL



-- Function to convert Forme to SDL Area
formeToArea :: Sim.Forme -> S.Area
formeToArea (Sim.Rectangle (Sim.C x y) w h) = S.mkArea (fromIntegral x) (fromIntegral y) (fromIntegral w) (fromIntegral h)
formeToArea _ = error "Unsupported Forme type for conversion to Area"

-- Function to draw all zones
drawZones :: Renderer -> [Sim.Zone] -> IO ()
drawZones renderer zones = mapM_ (drawZone renderer) zones




drawZone :: Renderer -> Sim.Zone -> IO ()
drawZone renderer zone = do
    let color = S.zoneColor zone  -- Assuming zoneColor is a function defined in Sprite.hs
    let area = formeToArea (Sim.zoneForme zone)
    S.createColoredSprite renderer color area  -- Adjust if needed

drawBuilding :: Renderer -> TextureMap -> Sim.Batiment -> IO ()
drawBuilding renderer tmap building = do
    let forme = Sim.getForme building
    let textureId = getTextureIdForBuilding building
    let texture = TM.fetchTexture textureId tmap
    let area = formeToArea forme
    SDL.copy renderer texture Nothing (Just area)  -- Use SDL.copy to render the texture


drawCitizen :: Renderer -> TextureMap -> Sim.Citoyen -> IO ()
drawCitizen renderer tmap citizen = do
    let textureId = getTextureIdForCitoyen citizen
    let texture = TM.fetchTexture textureId tmap
    let area = getCitizenArea citizen  -- Calculate the area for this citizen
    SDL.copy renderer texture Nothing (Just area)

-- Helper function to calculate the SDL area from citizen's position
getCitizenArea :: Sim.Citoyen -> S.Area
getCitizenArea citizen = 
    let (Sim.C x y) = Sim.citizenCoord citizen  -- Assume we can get the coordinates directly
    in S.mkArea (fromIntegral x) (fromIntegral y) 30 80  -- Width = 30, Height = 80

-- Load background image
loadBackgroundSprite :: Renderer -> TextureMap -> SpriteMap -> IO SpriteMap
loadBackgroundSprite renderer tmap smap = do
    let backgroundTextureId = TextureId "background"  -- Assurez-vous que cette ID correspond à une texture chargée dans tmap
    let backgroundArea = S.mkArea 0 0 640 480  -- Taille de l'arrière-plan
    let backgroundSprite = createBuildingSprite backgroundTextureId backgroundArea
    return $ SM.addSprite (SpriteId "background") backgroundSprite smap

-- Load character sprite
loadPerso :: Renderer -> FilePath -> TextureMap -> SpriteMap -> IO (TextureMap, SpriteMap)
loadPerso rdr path tmap smap = do
    tmap' <- TM.loadTexture rdr path (TextureId "perso") tmap
    let sprite = S.defaultScale $ S.addImage S.createEmptySprite $ S.createImage (TextureId "perso") (S.mkArea 0 0 200 200)
    let smap' = SM.addSprite (SpriteId "perso") sprite smap
    return (tmap', smap')

-- Function to display the current money in the game
displayMoney :: Renderer -> TTF.Font -> Int -> IO ()
displayMoney renderer font money = do
    let text = pack $ "Money: " ++ show money ++ " €"  -- Prepare text
    let color = V4 255 255 255 255  -- White color
    surface <- TTF.blended font color text  -- Create anti-aliased text surface
    texture <- SDL.createTextureFromSurface renderer surface  -- Create texture from surface
    SDL.freeSurface surface  -- Free the surface after creating the texture
    texInfo <- SDL.queryTexture texture  -- Get texture info to find out dimensions
    let textPos = P (V2 10 10)  -- Define position for the text
    let textRect = Rectangle textPos (V2 (SDL.textureWidth texInfo) (SDL.textureHeight texInfo))
    SDL.copy renderer texture Nothing (Just textRect)  -- Render the texture
    SDL.destroyTexture texture  -- Destroy the texture to clean up


-- Main game loop
gameLoop :: (RealFrac a, Show a) => a -> Renderer -> TextureMap -> SpriteMap -> K.KeyState -> Sim.Ville -> TTF.Font -> Int -> Int -> Sim.CitId -> Sim.BatId -> IO ()
gameLoop frameRate renderer tmap smap kbd ville font argent frameCount citId batId = do
    startTime <- time
    events <- pollEvents
    let kbd' = K.handleEvents events kbd
    let mouseState = MS.handleEventsMousePos events (MS.MyMouse False (-1) (-1))

    -- Update the game state based on mouse events
    (updatedVille, newBatId) <- MS.handleMouseEvents mouseState ville renderer tmap citId batId

    clear renderer
    -- Draw background
    S.displaySprite renderer tmap (SM.fetchSprite (SpriteId "background") smap)
    -- Draw all zones
    let zones = Sim.getZones updatedVille
    mapM_ (\zone -> drawZone renderer zone) zones
    -- Draw all buildings
    let buildings = Sim.getAllBuildings updatedVille
    mapM_ (\building -> drawBuilding renderer tmap building) buildings
    -- Draw all citizens
    let citizens = Sim.getAllCitizens updatedVille
    mapM_ (\citizen -> drawCitizen renderer tmap citizen) citizens

    -- Display current money
    displayMoney renderer font argent

    present renderer
    endTime <- time
    let elapsed = endTime - startTime
    let delayTime = max 0 (ceiling (1000 / frameRate - elapsed * 1000))
    threadDelay (delayTime * 1000)

    let newFrameCount = frameCount + 1
    let newArgent = if newFrameCount `mod` 500 == 0
                    then argent + 100 + (Sim.calculateMoney updatedVille)
                    else argent

                    
    -- Add immigrants every 500 frames
    let (newVille, newCitId) = if newFrameCount `mod` 500 == 0
                               then Sim.addImmigrants 3 updatedVille citId
                               else (updatedVille, citId)

    unless (K.keyPressed KeycodeEscape kbd') $ gameLoop frameRate renderer tmap smap kbd' newVille font newArgent newFrameCount newCitId newBatId



-- Handle mouse click on zones
handleMouseClick :: MyMouse -> [Sim.Zone] -> IO ()
handleMouseClick mouse zones = do
    let mouseX = MS.mouseX mouse
    let mouseY = MS.mouseY mouse
    mapM_ (checkZoneClick (mouseX, mouseY)) zones

-- Check if mouse click is within a zone and print limits
checkZoneClick :: (Int, Int) -> Sim.Zone -> IO ()
checkZoneClick (x, y) zone = do
    let forme = Sim.zoneForme zone
    let (nord, sud, ouest, est) = Sim.limites forme  -- Adjust to use named boundaries correctly
    when (x >= ouest && x <= est && y >= sud && y <= nord) $ do
        putStrLn $ "Zone clicked: " ++ show (Sim.limites forme)





--Pour charger les images, et attribuer à chaque batiment une image
loadBuildingTextures :: Renderer -> TextureMap -> IO TextureMap
loadBuildingTextures renderer initialMap = do
    tmapWithBackground <- TM.loadTexture renderer "assets/background.bmp" (TextureId "background") initialMap
    -- Charger la texture pour l'atelier et mettre à jour la carte de textures
    tmapWithAtelier <- TM.loadTexture renderer "assets/atelier.bmp" (TextureId "atelier") tmapWithBackground

    -- Charger la texture pour la cabane et mettre à jour la carte de textures
    tmapWithCabane <- TM.loadTexture renderer "assets/cabane.bmp" (TextureId "cabane") tmapWithAtelier

    -- Charger la texture pour l'épicerie et mettre à jour la carte de textures
    tmapWithEpicerie <- TM.loadTexture renderer "assets/epicerie.bmp" (TextureId "epicerie") tmapWithCabane

    -- Charger la texture pour le commissariat et mettre à jour la carte de textures finale
    tmapWithComico <- TM.loadTexture renderer "assets/comissariat.bmp" (TextureId "commissariat") tmapWithEpicerie

    tmapWithImmigrant <- TM.loadTexture renderer "assets/Immigrant.bmp" (TextureId "immigrant") tmapWithComico
    tmapWithHabitant <- TM.loadTexture renderer "assets/Habitant.bmp" (TextureId "habitant") tmapWithImmigrant
    tmapWithEmigrant <- TM.loadTexture renderer "assets/Emigrant.bmp" (TextureId "emigrant") tmapWithHabitant

    return tmapWithEmigrant


-- Function to draw all buildings
drawBuildings :: Renderer -> TextureMap -> [Sim.Batiment] -> IO ()
drawBuildings renderer tmap buildings = mapM_ (drawBuilding renderer tmap) buildings

loadSprite :: Renderer -> FilePath -> SpriteId -> TextureMap -> IO (Sprite, TextureMap)
loadSprite renderer filePath spriteId textureMap = do
    updatedTextureMap <- TM.loadTexture renderer filePath (TextureId $ show spriteId) textureMap
    let sprite = createBuildingSprite (TextureId $ show spriteId) (S.mkArea 0 0 200 200)
    return (sprite, updatedTextureMap)

-- Fonction pour charger les sprites en utilisant les textures déjà chargées
loadSprites :: Renderer -> TextureMap -> SpriteMap -> IO SpriteMap
loadSprites renderer tmap smapInitial = do
    -- Charger les sprites pour différents types de bâtiments
    atelier <- createAndAddSprite renderer tmap (SpriteId "atelier")
    cabane <- createAndAddSprite renderer tmap (SpriteId "cabane")
    epicerie <- createAndAddSprite renderer tmap (SpriteId "epicerie")
    commissariat <- createAndAddSprite renderer tmap (SpriteId "commissariat")
    habitant <- createAndAddSprite renderer tmap (SpriteId "habitant")
    immigrant <- createAndAddSprite renderer tmap (SpriteId "immigrant")
    emigrant <- createAndAddSprite renderer tmap (SpriteId "emigrant")

    -- Créer la SpriteMap en ajoutant chaque sprite
    let updatedSmap = foldl' (\smap (id, sprite) -> SM.addSprite id sprite smap) smapInitial [atelier, cabane, epicerie, commissariat,immigrant,emigrant,habitant]

    -- Créer et ajouter le sprite de background
    let backgroundSprite = createBuildingSprite (TextureId "background") (S.mkArea 0 0 640 480)
    let finalSmap = SM.addSprite (SpriteId "background") backgroundSprite updatedSmap

    return finalSmap


-- Fonction auxiliaire pour créer et ajouter un sprite
createAndAddSprite :: Renderer -> TextureMap -> SpriteId -> IO (SpriteId, Sprite)
createAndAddSprite renderer tmap spriteId = do
    let texture = TM.fetchTexture (TextureId $ show spriteId) tmap
    let sprite = createBuildingSprite (TextureId $ show spriteId) (S.mkArea 0 0 200 200)
    return (spriteId, sprite)


createBuildingSprite :: TextureId -> S.Area -> Sprite
createBuildingSprite textureId area =
    S.defaultScale $ S.addImage S.createEmptySprite $ S.createImage textureId area


createCitoyenSprite::TextureId -> S.Area -> Sprite
createCitoyenSprite textureId area =
    S.defaultScale $ S.addImage S.createEmptySprite $ S.createImage textureId area


-- Function to determine the texture ID based on the building type
getTextureIdForBuilding :: Sim.Batiment -> TextureId
getTextureIdForBuilding (Sim.Cabane _ _ _ _ _) = TextureId "cabane"
getTextureIdForBuilding (Sim.Atelier _ _ _ _ _) = TextureId "atelier"
getTextureIdForBuilding (Sim.Epicerie _ _ _ _ _) = TextureId "epicerie"
getTextureIdForBuilding (Sim.Commissariat _ _ _) = TextureId "commissariat"


getTextureIdForCitoyen:: Sim.Citoyen -> TextureId
getTextureIdForCitoyen (Sim.Habitant _ _ _ _) = TextureId "habitant"
getTextureIdForCitoyen (Sim.Immigrant _ _ _ ) = TextureId "immigrant"
getTextureIdForCitoyen (Sim.Emigrant _ _) = TextureId "emigrant"


main :: IO ()
main = do
    customInitialize  -- Use the custom initialization for SDL and fonts
    window <- createWindow (pack "Minijeu") $ defaultWindow { windowInitialSize = V2 800 800 }
    renderer <- createRenderer window (-1) defaultRenderer
    font <- TTF.load "assets/Roboto.ttf" 24  -- Load the font; specify the correct path and size
    
    tmap <- loadBuildingTextures renderer TM.createTextureMap
    smap <- loadSprites renderer tmap SM.createSpriteMap
    let kbd = K.createKeyState
    let ville = Sim.createInitialVille  -- Initialize your city here
    let argent = 0

    -- Check if the city respects the property
    let villeRespectsProperty = Sim.prop_ville ville
    putStrLn $ "Does the city respect the property? " ++ show villeRespectsProperty

    -- Proceed with the game loop
    gameLoop 60 renderer tmap smap kbd ville font argent 0 (Sim.CitId 0) (Sim.BatId 0)   -- Pass the font to the game loop